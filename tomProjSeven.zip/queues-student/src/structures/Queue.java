package structures;

import java.util.NoSuchElementException;

public class Queue<T> implements UnboundedQueueInterface<T> {
	public Node<T> head;
	public Node<T> tail;
	private int size;
	public Queue() {		
            // TODO 1
		head=null;
		tail=null;
		size=0;
    }
	
	public Queue(Queue<T> other) {
            // TODO 2
		/*Node<T> otherCur = other.head;
		head = new Node<T>(other.head.data);
		tail = new Node<T>(other.tail.data);
		Node<T> thisCur = head;
		otherCur = otherCur.link;
		while(otherCur!=null){
			
			Node<T> newNode = new Node<T>(otherCur.data);
			otherCur = otherCur.link;
			thisCur.link = newNode;
			thisCur = thisCur.link;
		}*/
		head = other.head;
		tail = other.tail;
		size = other.size;

	}
	
	@Override
	public boolean isEmpty() {
            // TODO 3
            return (size==0);
	}

	@Override
	public int size() {
            // TODO 4
            return size;
	}

	@Override
	public void enqueue(T element) {
            // TODO 5
		Node<T> newNode = new Node<T>(element);
		if(head==null&&tail==null){
			head = newNode;
			tail = newNode;
			size++;
		}
		else{
			tail.link=newNode;
			tail = tail.link;
			size++;
		}
	}

	@Override
	public T dequeue() throws NoSuchElementException {
            // TODO 6
			if(isEmpty()){throw new NoSuchElementException();}
			T data = head.data;
			if(head.link!=null){head = head.link;}
			else {
				head = null;
				tail=null;
				}
			size--;
            return data;
	}

	@Override
	public T peek() throws NoSuchElementException {
            // TODO 7
			if(head==null){throw new NoSuchElementException();}
            return head.data;
	}

	
	@Override
	public UnboundedQueueInterface<T> reversed() {
            // TODO 8
		Queue<T> newQ = new Queue<T>();
		Node<T> cur = newQ.head;
		@SuppressWarnings("unchecked")
		T[] flippy = (T[]) new Object[size];
		cur = head;
		int x = 0;
		while(cur!=null){
			flippy[x] = cur.data;
			//System.out.println(cur.data);
			x++;
			cur=cur.link;
			
		}
		for(int y = flippy.length-1;y>=0;y--){
			newQ.enqueue(flippy[y]);
		}
        return newQ;
	}
	


public static void main (String[] args){
	Queue<Integer> test = new Queue<Integer>();
	test.enqueue(1);
	test.enqueue(2);
	test.enqueue(3);
	UnboundedQueueInterface<Integer> flipped = test.reversed();
	System.out.print(flipped.dequeue());
	System.out.print(flipped.dequeue());
	System.out.print(flipped.dequeue());
}
}

