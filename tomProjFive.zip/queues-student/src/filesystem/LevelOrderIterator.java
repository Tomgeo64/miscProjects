package filesystem;

import java.io.File;
import java.io.FileNotFoundException;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.NoSuchElementException;
import structures.Queue;
import structures.Node;

/**
 * An iterator to perform a level order traversal of part of a 
 * filesystem. A level-order traversal is equivalent to a breadth-
 * first search.
 */
public class LevelOrderIterator extends FileIterator<File> {
	private File cur;
	private Queue<File> realQ;
	private File[] files;
	private File[] levelAbove;
	private int aboveVal = 0;
	private int xx = 0;
	/**
	 * Instantiate a new LevelOrderIterator, rooted at the rootNode.
	 * @param rootNode
	 * @throws FileNotFoundException if the rootNode does not exist
	 */
	public LevelOrderIterator(File rootNode) throws FileNotFoundException {
        	// TODO 1
		if(!rootNode.exists()) throw new FileNotFoundException();
		//fileQueue.enqueue(rootNode);
		/*cur = rootNode;
		files = cur.listFiles();
		levelAbove = new File[1];
		levelAbove[0] = null;*/
	
		//Arrays.sort(files);
		Queue<File> tempQ = new Queue<File>();
		realQ = new Queue<File>();
		tempQ.enqueue(rootNode);
		while(!tempQ.isEmpty()){
			File hold = tempQ.dequeue();
			realQ.enqueue(hold);
			File[] files = hold.listFiles();
			if(files==null){}
			else{
			Arrays.sort(files);
			for(File yy:files){
				tempQ.enqueue(yy);
			}
			}
		}
	}
	
	@Override
	public boolean hasNext() {
        	// TODO 2
		/*if(cur.isFile()) return false;
        if(cur.listFiles().length>0) return true;
        for(int x = 0;x<levelAbove.length;x++){
        	if(levelAbove[x]!=null) return true;
        }
        return false;*/
		return (!realQ.isEmpty());
	}

	@Override
	public File next() throws NoSuchElementException {
        	// TODO 3
		if(!hasNext()) throw new NoSuchElementException();
		return realQ.dequeue();
		/*boolean happened = false;
		if(xx>=files.length){
			xx=0;
			for(int y = 0;y<levelAbove.length;y++){//Go up a level, try this first
				if(levelAbove[y]!=null){
					cur = levelAbove[y];
					levelAbove[y]=null;
					happened = true;
					break;
				}
				levelAbove[y] = null;
			}
			if(cur.isDirectory() && happened) files = cur.listFiles();
			
			if(!happened){
				int z = 0;//Go down a level
				for(int x = 0;x<files.length;x++){
					if(files[x].isDirectory()) break;
					z=x;
				}
			levelAbove = files;
			files = files[z].listFiles();
			}
		}
		else{
			cur = files[xx];
			xx++;
		}
		fileQueue.enqueue(cur);
		return cur;*/
	}

	@Override
	public void remove() {
		// Leave this one alone.
		throw new UnsupportedOperationException();		
	}

}
