package guessme;

/**
 * This class defines a linked list node storing an integer.
 * Use primitive type int (do not use wrapper class Integer)
 * You must provide the following methods:
 * - a constructor
 * - a setInfo method and a getInfo method
 * - a setLink method and a getLink method
 */
public class LLIntegerNode {
	// TODO
	private LLIntegerNode link;
	private int info;
	private boolean possible;
	public LLIntegerNode (int information, LLIntegerNode link) {
		info = information; 
		this.link = link;
		possible = true;
	}
	public LLIntegerNode(int information,LLIntegerNode link,boolean pos){
		info = information;
		this.link = link;
		possible = pos;
	}
	public LLIntegerNode(int information,boolean pos){
		info = information;
		possible = pos;
	}
	public LLIntegerNode(int information){
		info = information;
		possible = true;
		link=null;
	}
	public LLIntegerNode getLink() {
		return link;
	}
	
	public void setLink (LLIntegerNode link) {
		this.link = link;
	}
	public int getInfo(){
		return info;
	}
	public void setInfo(int information){
		info = information;
	}
	public void setBool(boolean pos){
		possible = pos;
	}
	public boolean getBool(){
		return possible;
	}
		
}

