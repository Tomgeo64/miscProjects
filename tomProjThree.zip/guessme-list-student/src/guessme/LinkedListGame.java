package guessme;

/**
 * A LinkedList-based implementation of the Guess-A-Number game
 */
public class LinkedListGame {
	
	// TODO: declare data members as necessary
	private int guess;
	private boolean overCheck;
	private LLIntegerNode prevGuessHead = new LLIntegerNode(1000);
	private LLIntegerNode allNumsHead= new LLIntegerNode(1000,true);
	
	/********************************************************
	 * NOTE: for this project you must use linked lists
	 * implemented by yourself. You are NOT ALLOWED to use
	 * Java arrays of any type, or any class in the java.util
	 * package (such as ArrayList).
	 *******************************************************/	 
	
	/********************************************************
	 * NOTE: you are allowed to add new methods if necessary,
	 * but DO NOT remove any provided method, and do NOT add
	 * new files (as they will be ignored by the autograder).
	 *******************************************************/
	
	// LinkedListGame constructor method
	public LinkedListGame() {
		// TODO
		guess=1000;
		LLIntegerNode cur=allNumsHead;
		prevGuessHead.setInfo(0);
		prevGuessHead.setLink(null);
		allNumsHead.setInfo(1000);
		allNumsHead.setLink(null);
		for(int x = 1001;x<10000;x++){
			LLIntegerNode newNode=new LLIntegerNode(x,true);
			cur.setLink(newNode);
			cur=cur.getLink();
		}
		overCheck = false;
	}
	
	// Resets data members and game state so we can play again
	public void reset() {
		// TODO
		guess=1000;
		LLIntegerNode cur=allNumsHead;
		prevGuessHead.setInfo(0);
		prevGuessHead.setLink(null);
		allNumsHead.setInfo(1000);
		allNumsHead.setLink(null);
		for(int x = 1001;x<10000;x++){
			LLIntegerNode newNode=new LLIntegerNode(x,true);
			cur.setLink(newNode);
			cur=cur.getLink();
		}
		overCheck = false;
	}
	
	// Returns true if n is a prior guess; false otherwise.
	public boolean isPriorGuess(int n) {
		// TODO
		LLIntegerNode cur = prevGuessHead;
		boolean check = false;
		while(cur!=null){
			if(cur.getInfo()==n){check = true;}
			cur=cur.getLink();
		}
		return check;
		
	}
	
	// Returns the number of guesses so far.
	public int numGuesses() {
		// TODO
		int tot=0;
		LLIntegerNode cur = prevGuessHead;
		while(cur!=null){
			if(cur.getInfo()!=0){tot++;}
			cur = cur.getLink();
		}
		return tot;
	}
	
	/**
	 * Returns the number of matches between integers a and b.
	 * You can assume that both are 4-digits long (i.e. between 1000 and 9999).
	 * The return value must be between 0 and 4.
	 * 
	 * A match is the same digit at the same location. For example:
	 *   1234 and 4321 have 0 match;
	 *   1234 and 1114 have 2 matches (1 and 4);
	 *   1000 and 9000 have 3 matches (three 0's).
	 */
	public static int numMatches(int a, int b) {
		// TODO
		int matches = 0;
		for(int y =0;y<4;y++){
			if(a%10==b%10){matches++;}
			a=a/10;
			b=b/10;
		}
		return matches;
	}
	
	/**
	 * Returns true if the game is over; false otherwise.
	 * The game is over if the number has been correctly guessed
	 * or if no candidate is left.
	 */
	public boolean isOver() {
		// TODO
		return overCheck;
	}
	
	/**
	 * Returns the guess number and adds it to the list of prior guesses.
	 * The insertion should occur at the end of the prior guesses list,
	 * so that the order of the nodes follow the order of prior guesses.
	 */	
	public int getGuess() {
		// TODO: add guess to the list of prior guesses.
		LLIntegerNode cur=prevGuessHead;
		if(prevGuessHead.getInfo()==0){
			prevGuessHead.setInfo(guess);
			return guess;
		}
		LLIntegerNode newNode = new LLIntegerNode(guess,null);
		
		while(cur.getLink()!=null){
		cur=cur.getLink();
		}
		cur.setLink(newNode);
		return guess;
	}
	
	/**
	 * Updates guess based on the number of matches of the previous guess.
	 * If nmatches is 4, the previous guess is correct and the game is over.
	 * Check project description for implementation details.
	 * 
	 * Returns true if the update has no error; false if no candidate 
	 * is left (indicating a state of error);
	 */
	public boolean updateGuess(int nmatches) {
		// TODO
		boolean checker = false;
		LLIntegerNode cur=allNumsHead;
		LLIntegerNode temp = new LLIntegerNode(0);
		LLIntegerNode tempp = temp;
		if(nmatches==4){
			overCheck = true;
			return true;
		}
		while(cur!=null){
			if(numMatches(guess,cur.getInfo())==nmatches){
				if(temp.getInfo()==0){
					temp.setInfo(cur.getInfo());
				}
				else{
					LLIntegerNode input = new LLIntegerNode(cur.getInfo());
					tempp.setLink(input);
					tempp = input;
				}
			}
			cur=cur.getLink();
		}
		allNumsHead = temp;
		guess = allNumsHead.getInfo();
		if(allNumsHead.getLink()!=null){
			checker = true;
		}
		
		return checker;
	}
		
	
	// Returns the head of the prior guesses list.
	// Returns null if there hasn't been any prior guess
	public LLIntegerNode priorGuesses() {
		// TODO
		if(prevGuessHead.getInfo()==0){return null;}
		else{return prevGuessHead;}
	}
	
	/**
	 * Returns the list of prior guesses as a String. For example,
	 * if the prior guesses are 1000, 2111, 3222, in that order,
	 * the returned string should be "1000, 2111, 3222", in the same order,
	 * with every two numbers separated by a comma and space, except the
	 * last number (which should not be followed by either comma or space).
	 *
	 * Returns an empty string if here hasn't been any prior guess
	 */
	public String priorGuessesString() {
		// TODO
		String returner = "";
		if(prevGuessHead.getInfo()==0){return returner;}
		LLIntegerNode cur = prevGuessHead;
		while(cur!=null){
			if(cur.getLink()!=null){returner = returner + Integer.toString(cur.getInfo())+", ";}
			else{returner=returner+cur.getInfo();}
			cur=cur.getLink();
		}
		return returner;
	}
	
}
