package structures;

public class LLNode<V> {
	public V value;
	public LLNode<V> link;
	public Integer priority;
	public LLNode(V data) { this.value=data;}
	public LLNode(V data, LLNode<V> next, Integer priority) {
		this.value = data; this.link=next;
	}
}
