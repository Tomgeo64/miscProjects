package structures;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;

import comparators.IntegerComparator;

public class StudentArrayHeap<P, V> extends AbstractArrayHeap<P, V> {
	protected StudentArrayHeap(Comparator<P> comparator) {
		super(comparator);
		// TODO Auto-generated constructor stub
	}

	
	@Override
	protected int getLeftChildOf(int index) throws IndexOutOfBoundsException{
		// TODO Auto-generated method stub
		if( index<0) throw new IndexOutOfBoundsException();
		return index*2 + 1;
	}

	@Override
	protected int getRightChildOf(int index) throws IndexOutOfBoundsException{
		// TODO Auto-generated method stub
		if( index<0) throw new IndexOutOfBoundsException();
		return index*2 + 2;
	}

	@Override
	protected int getParentOf(int index) throws IndexOutOfBoundsException{
		// TODO Auto-generated method stub
		if( index<1) throw new IndexOutOfBoundsException();
		return (index - 1)/2;
	}

	@Override
	protected void bubbleUp(int index) {
		// TODO Auto-generated method stub
			/*if(heap.size()==1 ||heap.size()-1==index) return;
			P prio1 = heap.get(index).getPriority();
			P prio2 = heap.get((index-1)/2).getPriority();
			while(comparator.compare(prio1,prio2)>0 && index<heap.size()){
				swap(index,(index-1)/2);
				index=(index-1)/2;
				prio1 = heap.get(index).getPriority();
				prio2 = heap.get((index-1)/2).getPriority();
			}*/
		if(index<=0) return;
		P prio1 = heap.get(index).getPriority();
		P prio2 = heap.get((index-1)/2).getPriority();
		if(comparator.compare(prio1, prio2)>0){
			swap(index,(index-1)/2);
			bubbleUp((index-1)/2);
		}
		else return;
	}
 
	@Override
	protected void bubbleDown(int index) {
		// TODO Auto-generated method stub
		/*if(heap.size()==1) return;
		P prio1 = heap.get(index).getPriority();
		P prio2 = heap.get((index-1)/2).getPriority();
		while(comparator.compare(prio1,prio2)<0){
			swap(index,(index-1)/2);
			index=(index-1)/2;
			prio1 = heap.get(index).getPriority();
			prio2 = heap.get(index+1).getPriority();
		}*/
		if(index>heap.size()) return;
		P prio1 = heap.get(index).getPriority();
		P prio2;
		P prio3;
		if(heap.size()<index*2+3) return;
			prio2 = heap.get((index*2)+1).getPriority();
			prio3 = heap.get((index*2)+2).getPriority();
		if(comparator.compare(prio1, prio2)<0){
			swap(index,index*2+1);
			bubbleDown(index*2+1);
		}
		else if(comparator.compare(prio1, prio3)<0){
			swap(index,index*2+2);
			bubbleDown(index*2+2);
		}
		else return;
	}
}

