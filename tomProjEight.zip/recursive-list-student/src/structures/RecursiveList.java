package structures;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.lang.IllegalStateException;

public class RecursiveList<T> implements ListInterface<T>{
	private LLNode<T> head;
	private LLNode<T> cur;
	private int size=0;
	private int count=0;
	@Override
	public Iterator iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public ListInterface<T> insertFirst(T elem) throws NullPointerException{
		// TODO Auto-generated method stub
		if(elem==null)throw new NullPointerException();
		LLNode<T> newNode = new LLNode<T>(elem,head);
		head = newNode;
		size++;
		return this;
	}

	@Override
	public ListInterface<T> insertLast(T elem) throws NullPointerException{
		// TODO Auto-generated method stub
		if(elem==null)throw new NullPointerException();
		cur = head;
		
		if(size>1)goTo(size-1);
		if(size==0){
			head = new LLNode<T>(elem,null);
			size++;
			return this;
		}
		LLNode<T> newNode = new LLNode<T>(elem,null);
		cur.link = newNode;
		size++;
		return this;
	}

	@Override
	public ListInterface<T> insertAt(int index, T elem) throws IndexOutOfBoundsException, NullPointerException{//can't decide if it wants Object elem or T elem
		// TODO Auto-generated method stub
		if(index>size ||index<0) throw new IndexOutOfBoundsException();
		if(elem==null) throw new NullPointerException();
		cur = head;
		if(index==0){
			LLNode<T> newNode = new LLNode<T>(elem,cur);
			head = newNode;
			size++;
			return this;
		}
		goTo(index-1);
		LLNode<T> previous = cur;
		cur = head;
		goTo(index);
		LLNode<T> newNode = new LLNode<T>(elem,cur);
		previous.link = newNode;
		size++;
		return this;
	}

	@Override
	public T removeFirst() throws IllegalStateException{
		// TODO Auto-generated method stub
		if(isEmpty()) throw new IllegalStateException();
		LLNode<T> hold = head;
		if(size>1)
			head=head.link;
		else
			head = null;
		size--;
		return hold.data;
	}

	@Override
	public T removeLast() throws IllegalStateException{
		// TODO Auto-generated method stub
		if(isEmpty()) throw new IllegalStateException();
		cur = head;
		
		goTo(size-1);
		LLNode<T> hold = cur;
		cur=null;
		if(size==1){
			head = null;
		}
		size--;
		return hold.data;
	}

	@Override
	public T removeAt(int i) throws IndexOutOfBoundsException{
		// TODO Auto-generated method stub
		if(size<=i||i<0) throw new IndexOutOfBoundsException();
		cur = head;
		if(i!=0){
			goTo(i-1);
		}
		if(i==0){
			return removeFirst();
		}
		LLNode<T> hold = cur.link;
		if(i==size-1){
			cur.link=null;
		}
		else{
			cur.link=cur.link.link;
		}
		size--;
		return hold.data;
	}

	@Override
	public T getFirst() throws IllegalStateException{
		// TODO Auto-generated method stub
		if(isEmpty())throw new IllegalStateException();
		return head.data;
	}

	@Override
	public T getLast() throws IllegalStateException{
		// TODO Auto-generated method stub
		if(isEmpty())throw new IllegalStateException();
		cur = head;
		goTo(size-1);
		return cur.data;
	}

	@Override
	public T get(int i) throws IndexOutOfBoundsException{
		// TODO Auto-generated method stub
		if(size<=i||i<0)throw new IndexOutOfBoundsException();
		cur = head;
		goTo(i);
		return cur.data;
	}

	@Override
	public boolean remove(T elem) throws NullPointerException{
		// TODO Auto-generated method stub
		/*if(elem==null) throw new NullPointerException();
		count = 0;
		cur = head;
		int ind = indexOf(elem);
		T data = removeAt(ind);
		if(data==null)return false;
		return true;*/
		count = 0;
		cur= head;
		LLNode<T> hold = checkThrough(elem,size);
		if(hold==null)return false;
		boolean checkIt = false;
		cur = head;
		size--;
		if(count>1)count--;
		else if(count==1){
			head = head.link;
			return true;
		}
		goTo(count-1);
		
		if(cur.link==null){
			size++;
			removeLast();
			checkIt=true;
		}
		else if(cur.link!=null){
			if(cur.link.link!=null){
				cur.link=cur.link.link;
				checkIt=true;
			}
		}
		else if(cur==head){
			size++;
			removeFirst();
			checkIt=true;
		}
		
		if(checkIt)return true;
		return false;
	}

	@Override
	public int indexOf(T elem) throws NullPointerException{
		// TODO Auto-generated method stub
		if(elem==null)throw new NullPointerException();
		count=0;
		cur = head;
		LLNode<T> hold = checkThrough(elem,size);
		if(hold==null)return -1;
		return count-1;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		if(size<1)return true;
		return false;
	}
	private void goTo(int x){
		if(x==0){
			return;
		}
		else{
			cur=cur.link;
			count++;
			goTo(x-1);
		}
	}
	private LLNode<T> checkThrough(Object elem,int x){
		if(x==0){
			return null;
		}
		else{
			if(cur.data==elem){
				count++;
				return cur;
			}
			cur=cur.link;
			count++;
			return checkThrough(elem,x-1);
		}
	}
	public void printList(){
		for(int x = 0;x<size;x++){
			System.out.print(get(x));
		}
	}
}
