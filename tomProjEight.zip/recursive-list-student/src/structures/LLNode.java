package structures;

public class LLNode<T> {
	public T data;
	public LLNode<T> link;
	public LLNode<T> prev;
	public LLNode(T data) { this.data=data;}
	public LLNode(T data, LLNode<T> next) {
		this.data = data; this.link=next;
	}
}

