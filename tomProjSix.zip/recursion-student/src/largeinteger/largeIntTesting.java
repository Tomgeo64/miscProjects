package largeinteger;


public class largeIntTesting {
	public static void main(String[] args){
		LargeInteger number = new LargeInteger("123");
		number = number.multiply(123);
	System.out.println(number.toString());
	}
}
