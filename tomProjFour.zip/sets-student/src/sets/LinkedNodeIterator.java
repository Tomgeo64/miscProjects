package sets;

import java.util.Iterator;
import java.util.NoSuchElementException;

class LinkedNodeIterator<E> implements Iterator<E> {
    private LinkedNode<E> cur;
  
  // Constructors
  public LinkedNodeIterator(LinkedNode<E> head) {
      cur = head;
  }

  @Override
  public boolean hasNext() {
    // TODO (3)
	  if(cur!=null){return true;}
    return false;
  }

  @Override
  public E next() {
    // TODO (4)new LinkedSet<E>(head);
	  LinkedNode<E> temp = cur;
	  if(hasNext()==false)throw new NoSuchElementException();
	  cur=cur.getNext();
    return temp.getData();
  }

  @Override
  public void remove() {
    // Nothing to change for this method
    throw new UnsupportedOperationException();
  }
}
